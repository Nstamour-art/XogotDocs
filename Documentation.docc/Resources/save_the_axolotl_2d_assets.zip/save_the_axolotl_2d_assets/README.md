# Save the Axolotl 2D assets

Used by the "Your first 2D game" tutorial for Xogot:

https://docs.xogot.com/tutorials/xogot-tutorials
